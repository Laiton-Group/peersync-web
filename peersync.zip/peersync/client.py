import json, os, sys, threading, time, urllib.request, urllib.error, hashlib
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

BG = "#1a1a2e"
FG = "#e0e0e0"
ACCENT = "#00d4aa"
DARK2 = "#16213e"
DARK3 = "#0f3460"
SEL = "#1a4a6e"

class APIClient:
    def __init__(self):
        self.base = ""
        self.nick = ""
        self.password = ""
        self.role = "normal"
        self.channels = {"general": []}
        self.all_msgs = []
        self.last_id = 0
        self.running = True

    def connect(self, host, port, nick, password):
        self.nick = nick
        self.password = password
        self.base = f"http://{host}:{port}"
        if port == 443: self.base = f"https://{host}"
        try:
            r = self._post("/api/login", {"user": nick, "pass": password})
            if not r or not r.get("ok"):
                return False
            self.role = r.get("role", "normal")
            ch = self._get("/api/channels")
            if ch is not None:
                self.channels = {c: [] for c in ch}
                if "general" not in self.channels: self.channels["general"] = []
                msgs = self._get("/api/msgs?after=0")
                if msgs is None: return False
                for m in msgs:
                    self.all_msgs.append(m)
                    if m["id"] > self.last_id: self.last_id = m["id"]
                return True
        except: pass
        return False

    def _get(self, path):
        try:
            resp = urllib.request.urlopen(f"{self.base}{path}", timeout=5)
            return json.loads(resp.read())
        except: return None

    def _post(self, path, data):
        try:
            req = urllib.request.Request(f"{self.base}{path}", data=json.dumps(data).encode(), headers={"Content-Type": "application/json"})
            resp = urllib.request.urlopen(req, timeout=5)
            return json.loads(resp.read())
        except: return None

    def send_msg(self, channel, text):
        m = self._post("/api/send", {"user": self.nick, "pass": self.password, "text": text, "chan": channel})
        if m and m.get("ok") != False:
            self.all_msgs.append(m)
            if m["id"] > self.last_id: self.last_id = m["id"]

    def create_channel(self, chan):
        r = self._post("/api/channels/create", {"user": self.nick, "pass": self.password, "chan": chan})
        return r.get("ok") if r else False

    def delete_channel(self, chan):
        r = self._post("/api/channels/delete", {"user": self.nick, "pass": self.password, "chan": chan})
        return r.get("ok") if r else False

    def poll(self):
        msgs = self._get(f"/api/msgs?after={self.last_id}")
        if msgs is None: self.running = False; return []
        new = []
        for m in msgs:
            if m not in self.all_msgs: self.all_msgs.append(m); new.append(m)
            if m["id"] > self.last_id: self.last_id = m["id"]
        chs = self._get("/api/channels")
        if chs:
            for c in chs:
                if c not in self.channels: self.channels[c] = []
        return new

class ChatGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("PeerSync Chat")
        self.root.geometry("900x600")
        self.root.configure(bg=BG)
        self.client = APIClient()
        self._connect_dialog()
        self.root.protocol("WM_DELETE_WINDOW", self._quit)

    def _style(self):
        s = ttk.Style()
        s.theme_use("default" if "default" in s.theme_names() else "alt")
        s.configure(".", background=BG, foreground=FG, fieldbackground=DARK2, selectbackground=SEL, font=("Consolas", 10))
        s.configure("Treeview", background=DARK2, foreground=FG, fieldbackground=DARK2, rowheight=24, font=("Consolas", 10))
        s.map("Treeview", background=[("selected", SEL)], foreground=[("selected", ACCENT)])
        s.configure("TEntry", fieldbackground=DARK2, foreground=FG)
        s.configure("TButton", background=DARK3, foreground=FG, font=("Consolas", 9))
        s.map("TButton", background=[("active", SEL)])

    def _connect_dialog(self):
        self._style()
        win = tk.Toplevel(self.root, bg=BG)
        win.title("Connexion")
        win.geometry("380x250+200+200")
        win.resizable(False, False)
        win.protocol("WM_DELETE_WINDOW", self._quit)
        win.update_idletasks()
        win.grab_set()

        tk.Label(win, text="Serveur (host:port):", bg=BG, fg=FG, anchor="w", font=("Consolas", 10)).pack(fill="x", padx=15, pady=(15,0))
        self.host_entry = tk.Entry(win, bg=DARK2, fg=FG, insertbackground=ACCENT, font=("Consolas", 10), relief="flat", bd=4)
        self.host_entry.insert(0, "serverirc2-production.up.railway.app:443")
        self.host_entry.pack(fill="x", padx=15, pady=4)

        tk.Label(win, text="Pseudonyme:", bg=BG, fg=FG, anchor="w", font=("Consolas", 10)).pack(fill="x", padx=15, pady=(4,0))
        self.nick_entry = tk.Entry(win, bg=DARK2, fg=FG, insertbackground=ACCENT, font=("Consolas", 10), relief="flat", bd=4)
        import getpass; self.nick_entry.insert(0, getpass.getuser()[:20])
        self.nick_entry.pack(fill="x", padx=15, pady=4)

        tk.Label(win, text="Mot de passe:", bg=BG, fg=FG, anchor="w", font=("Consolas", 10)).pack(fill="x", padx=15, pady=(4,0))
        self.pass_entry = tk.Entry(win, bg=DARK2, fg=FG, insertbackground=ACCENT, font=("Consolas", 10), relief="flat", bd=4, show="*")
        self.pass_entry.insert(0, "")
        self.pass_entry.pack(fill="x", padx=15, pady=4)

        tk.Button(win, text="[ CONNEXION ]", command=self._do_connect, bg=DARK3, fg=ACCENT, font=("Consolas", 10, "bold"), relief="flat", bd=4, padx=20, cursor="hand2").pack(pady=10)

    def _do_connect(self):
        hp = self.host_entry.get().strip(); nick = self.nick_entry.get().strip()[:20]; pwd = self.pass_entry.get().strip()
        if ":" in hp: host, port = hp.rsplit(":", 1); port = int(port)
        else: host, port = hp, 8000
        if not nick: nick = "user"
        nick = nick.lower()
        if not pwd: messagebox.showerror("Erreur", "Mot de passe requis"); return
        if self.client.connect(host, port, nick, pwd):
            self._build_ui(); self._start_poll()
        else:
            messagebox.showerror("Erreur", "Connexion impossible (pseudo deja pris ou serveur indisponible)")

    def _build_ui(self):
        for w in self.root.winfo_children(): w.destroy()
        self.root.configure(bg=BG)
        panes = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, sashwidth=2, bg=DARK3)
        panes.pack(fill="both", expand=True)
        left = tk.Frame(panes, bg=DARK2); right = tk.Frame(panes, bg=BG)
        panes.add(left, width=220, minsize=140); panes.add(right, width=680, minsize=320)

        top = tk.Frame(left, bg=DARK3)
        top.pack(fill="x")
        role_tag = "👑" if self.client.role == "admin" else "  "
        tk.Label(top, text=f"  ◆  SALONS  {role_tag}", bg=DARK3, fg=ACCENT, font=("Consolas", 10, "bold")).pack(side="left", padx=8, pady=4)

        self.tree = ttk.Treeview(left, show="tree", selectmode="browse")
        self.tree.pack(fill="both", expand=True)
        self.tree.insert("", "end", "general", text="  ◆  #general", open=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_channel_select)
        self.tree.selection_set("general")

        btn_f = tk.Frame(left, bg=DARK2)
        btn_f.pack(fill="x", pady=3, padx=4)
        if self.client.role == "admin":
            tk.Button(btn_f, text="[ + ]", command=self._join_dialog, bg=DARK3, fg=ACCENT, font=("Consolas", 9, "bold"), relief="flat", bd=3, cursor="hand2").pack(side="left", fill="x", expand=True, padx=(0,2))
            tk.Button(btn_f, text="[ - ]", command=self._delete_dialog, bg="#4a0000", fg="#ff4444", font=("Consolas", 9, "bold"), relief="flat", bd=3, cursor="hand2").pack(side="right", fill="x", expand=True, padx=(2,0))
        else:
            tk.Label(btn_f, text=f"  ({self.client.nick})", bg=DARK2, fg="#888", font=("Consolas", 9)).pack()

        hdr = tk.Frame(right, bg=DARK3)
        hdr.pack(fill="x")
        self.chan_label = tk.Label(hdr, text="  MESSAGES  #general", bg=DARK3, fg=ACCENT, font=("Consolas", 10, "bold"), anchor="w")
        self.chan_label.pack(fill="x", padx=8, pady=4)

        self.msg_text = tk.Text(right, bg=DARK2, fg=FG, insertbackground=ACCENT, font=("Consolas", 10), relief="flat", bd=0, padx=10, pady=6, state="disabled", wrap="word")
        self.msg_scroll = tk.Scrollbar(right, orient="vertical", command=self.msg_text.yview, bg=DARK3, troughcolor=DARK2)
        self.msg_text.configure(yscrollcommand=self.msg_scroll.set)
        self.msg_text.pack(side="left", fill="both", expand=True)
        self.msg_scroll.pack(side="right", fill="y")

        bottom = tk.Frame(right, bg=BG)
        bottom.pack(fill="x", padx=6, pady=(0,6))
        self.entry = tk.Entry(bottom, bg=DARK2, fg=FG, insertbackground=ACCENT, font=("Consolas", 11), relief="flat", bd=5)
        self.entry.pack(side="left", fill="x", expand=True, ipady=3)
        self.entry.bind("<Return>", self._send_msg)
        tk.Button(bottom, text="ENVOYER", command=self._send_msg, bg=DARK3, fg=ACCENT, font=("Consolas", 9, "bold"), relief="flat", bd=3, padx=12, cursor="hand2").pack(side="right", padx=(4,0))

        self.root.title(f"PeerSync - {self.client.nick} [{self.client.role}]")
        self._refresh_msgs()

    def _join_dialog(self):
        ch = simpledialog.askstring("Creer salon", "Nom du salon:", parent=self.root)
        if ch and ch.strip():
            ch = ch.strip().lower().replace(" ", "-")
            if self.client.create_channel(ch):
                if ch not in self.client.channels:
                    self.client.channels[ch] = []
                    self.tree.insert("", "end", ch, text=f"  ◆  #{ch}", open=True)
                self.tree.selection_set(ch)
            else:
                messagebox.showerror("Erreur", "Impossible de creer le salon")

    def _delete_dialog(self):
        ch = self._current_channel()
        if ch == "general": messagebox.showerror("Erreur", "Impossible de supprimer #general"); return
        if messagebox.askyesno("Supprimer", f"Supprimer #{ch} ?"):
            if self.client.delete_channel(ch):
                self.tree.delete(ch)
                if ch in self.client.channels: del self.client.channels[ch]
                self.tree.selection_set("general")
                self._refresh_msgs()
            else:
                messagebox.showerror("Erreur", "Impossible de supprimer")

    def _on_channel_select(self, e):
        sel = self.tree.selection()
        if sel:
            self.chan_label.configure(text=f"  MESSAGES  #{sel[0]}")
            self._refresh_msgs()

    def _current_channel(self):
        sel = self.tree.selection(); return sel[0] if sel else "general"

    def _send_msg(self, event=None):
        text = self.entry.get().strip()
        if not text: return
        ch = self._current_channel()
        self.client.send_msg(ch, text)
        self.entry.delete(0, "end")
        self._refresh_msgs()

    def _refresh_msgs(self):
        self.msg_text.configure(state="normal")
        self.msg_text.delete("1.0", "end")
        ch = self._current_channel()
        msgs = [m for m in self.client.all_msgs if m["chan"] == ch]
        for m in msgs[-200:]:
            nick = m["user"]
            text = m["text"]
            tag = "me" if nick == self.client.nick else "them"
            t = time.strftime("%H:%M", time.localtime(m["id"]/1000))
            self.msg_text.insert("end", f" {t} ", ("time",))
            self.msg_text.insert("end", f"<{nick}>", (tag,))
            self.msg_text.insert("end", f" {text}\n", ("msg",))
        self.msg_text.tag_config("time", foreground="#555", font=("Consolas", 8))
        self.msg_text.tag_config("me", foreground=ACCENT, font=("Consolas", 10, "bold"))
        self.msg_text.tag_config("them", foreground="#ffd700", font=("Consolas", 10, "bold"))
        self.msg_text.tag_config("msg", foreground=FG, font=("Consolas", 10))
        self.msg_text.configure(state="disabled")
        self.msg_text.see("end")

    def _start_poll(self):
        def poll():
            known = set(self.client.channels.keys())
            while self.client.running:
                new = self.client.poll()
                if new: self.root.after(0, self._refresh_msgs)
                for c in self.client.channels:
                    if c not in known:
                        known.add(c)
                        self.root.after(0, lambda ch=c: self.tree.insert("", "end", ch, text=f"  ◆  #{ch}", open=True) if ch not in self.tree.get_children() else None)
                time.sleep(2)
        threading.Thread(target=poll, daemon=True).start()

    def _quit(self):
        self.client.running = False; self.root.destroy()

def main():
    app = ChatGUI(); app.root.mainloop()

if __name__ == "__main__":
    main()

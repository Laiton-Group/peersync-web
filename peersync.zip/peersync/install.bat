@echo off
setlocal
set DIR=%~dp0
echo === PeerSync Chat Install (Windows) ===
set /p SERVER="Serveur (host:port) [serverirc2-production.up.railway.app:443]: "
if "%SERVER%"=="" set SERVER=serverirc2-production.up.railway.app:443
set /p PASSWORD="Mot de passe (laisse vide si node): "
if not "%PASSWORD%"=="" (
  echo {"hub": "%SERVER%", "pass": "%PASSWORD%"} > "%DIR%config.json"
) else (
  echo {"hub": "%SERVER%"} > "%DIR%config.json"
)

:: Add shortcut to Startup
set STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
echo set WshShell = WScript.CreateObject("WScript.Shell") > "%TEMP%\peersync.vbs"
echo set Shortcut = WshShell.CreateShortcut("%STARTUP%\PeerSync Chat.lnk") >> "%TEMP%\peersync.vbs"
echo Shortcut.TargetPath = "pythonw.exe" >> "%TEMP%\peersync.vbs"
echo Shortcut.Arguments = """%DIR%client.py""" >> "%TEMP%\peersync.vbs"
echo Shortcut.WorkingDirectory = "%DIR%" >> "%TEMP%\peersync.vbs"
echo Shortcut.Save >> "%TEMP%\peersync.vbs"
cscript //nologo "%TEMP%\peersync.vbs"
del "%TEMP%\peersync.vbs"

echo Lancement de PeerSync Chat...
start /B pythonw "%DIR%client.py"
echo PeerSync Chat est lance.
pause

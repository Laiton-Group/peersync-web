@echo off
set DIR=%~dp0
set PY=

where pythonw >nul 2>&1 && set PY=pythonw
if "%PY%"=="" (
  where python >nul 2>&1 && set PY=python
)
if "%PY%"=="" (
  echo [PeerSync] Python non trouve.
  echo [PeerSync] Telechargement de Python 3.12...
  curl -# -o "%TEMP%\python-installer.exe" https://www.python.org/ftp/python/3.12.5/python-3.12.5-amd64.exe
  echo [PeerSync] Installation silencieuse...
  "%TEMP%\python-installer.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_tkinter=1
  del "%TEMP%\python-installer.exe"
  for %%p in (
    "%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe"
    "%USERPROFILE%\AppData\Local\Programs\Python\Python312\pythonw.exe"
  ) do if exist %%p set PY=%%p
  if "%PY%"=="" (
    echo [PeerSync] ERREUR: Python installe mais introuvable.
    echo [PeerSync] Lancez manuellement: python client.py
    pause
    exit /b 1
  )
)
start /B "" %PY% "%DIR%client.py"
exit

import json, os, sys, threading, time, urllib.request, urllib.error
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

BG = "#f5f5f5"
FG = "#222"
ACCENT = "#1976D2"
DARK2 = "#ffffff"
DARK3 = "#e3f2fd"
SEL = "#bbdefb"
BTN = "#1976D2"
BTN_FG = "white"

class APIClient:
    def __init__(self):
        self.base = ""
        self.nick = ""
        self.password = ""
        self.role = "normal"
        self.channels = {"general": []}
        self.all_msgs = []
        self.last_id = 0
        self.running = True

    def connect(self, host, port, nick, password):
        self.nick = nick
        self.password = password
        self.base = f"http://{host}:{port}"
        if port == 443: self.base = f"https://{host}"
        try:
            r = self._post("/api/login", {"user": nick, "pass": password})
            if not r or not r.get("ok"): return False
            self.role = r.get("role", "normal")
            ch = self._get("/api/channels")
            if ch is not None:
                self.channels = {c: [] for c in ch}
                if "general" not in self.channels: self.channels["general"] = []
                msgs = self._get("/api/msgs?after=0")
                if msgs is None: return False
                for m in msgs:
                    self.all_msgs.append(m)
                    if m["id"] > self.last_id: self.last_id = m["id"]
                return True
        except: pass
        return False

    def _get(self, path):
        try:
            resp = urllib.request.urlopen(f"{self.base}{path}", timeout=5)
            return json.loads(resp.read())
        except: return None

    def _post(self, path, data):
        try:
            req = urllib.request.Request(f"{self.base}{path}", data=json.dumps(data).encode(), headers={"Content-Type": "application/json"})
            resp = urllib.request.urlopen(req, timeout=5)
            return json.loads(resp.read())
        except: return None

    def send_msg(self, channel, text):
        m = self._post("/api/send", {"user": self.nick, "pass": self.password, "text": text, "chan": channel})
        if m and m.get("ok") != False:
            self.all_msgs.append(m)
            if m["id"] > self.last_id: self.last_id = m["id"]

    def create_channel(self, chan):
        r = self._post("/api/channels/create", {"user": self.nick, "pass": self.password, "chan": chan})
        return r.get("ok") if r else False

    def delete_channel(self, chan):
        r = self._post("/api/channels/delete", {"user": self.nick, "pass": self.password, "chan": chan})
        return r.get("ok") if r else False

    def poll(self):
        msgs = self._get(f"/api/msgs?after={self.last_id}")
        if msgs is None: self.running = False; return []
        new = []
        for m in msgs:
            if m not in self.all_msgs: self.all_msgs.append(m); new.append(m)
            if m["id"] > self.last_id: self.last_id = m["id"]
        chs = self._get("/api/channels")
        if chs:
            for c in chs:
                if c not in self.channels: self.channels[c] = []
        return new

class ChatGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("PeerSync Chat")
        self.root.geometry("850x550")
        self.root.configure(bg=BG)
        self.client = APIClient()
        self._connect_dialog()
        self.root.protocol("WM_DELETE_WINDOW", self._quit)

    def _connect_dialog(self):
        win = tk.Toplevel(self.root, bg=BG)
        win.title("Connexion")
        win.geometry("400x280+200+200")
        win.resizable(False, False)
        win.protocol("WM_DELETE_WINDOW", self._quit)
        win.update_idletasks()
        win.grab_set()

        tk.Label(win, text="Serveur :", bg=BG, fg=FG, anchor="w", font=("Segoe UI", 10)).pack(fill="x", padx=20, pady=(20,2))
        self.host_entry = tk.Entry(win, font=("Segoe UI", 10), bd=2, relief="solid")
        self.host_entry.insert(0, "serverirc2-production.up.railway.app:443")
        self.host_entry.pack(fill="x", padx=20, pady=2, ipady=3)

        tk.Label(win, text="Pseudo :", bg=BG, fg=FG, anchor="w", font=("Segoe UI", 10)).pack(fill="x", padx=20, pady=(8,2))
        self.nick_entry = tk.Entry(win, font=("Segoe UI", 10), bd=2, relief="solid")
        import getpass; self.nick_entry.insert(0, getpass.getuser()[:20])
        self.nick_entry.pack(fill="x", padx=20, pady=2, ipady=3)

        tk.Label(win, text="Mot de passe :", bg=BG, fg=FG, anchor="w", font=("Segoe UI", 10)).pack(fill="x", padx=20, pady=(8,2))
        self.pass_entry = tk.Entry(win, font=("Segoe UI", 10), bd=2, relief="solid", show="*")
        self.pass_entry.pack(fill="x", padx=20, pady=2, ipady=3)

        tk.Button(win, text="Connexion", command=self._do_connect, bg=BTN, fg=BTN_FG, font=("Segoe UI", 11, "bold"), bd=0, padx=30, pady=6, cursor="hand2").pack(pady=15)

    def _do_connect(self):
        hp = self.host_entry.get().strip(); nick = self.nick_entry.get().strip()[:20]; pwd = self.pass_entry.get().strip()
        if ":" in hp: host, port = hp.rsplit(":", 1); port = int(port)
        else: host, port = hp, 8000
        if not nick: nick = "user"
        nick = nick.lower()
        if not pwd: messagebox.showerror("Erreur", "Mot de passe requis"); return
        if self.client.connect(host, port, nick, pwd):
            self.root.deiconify()
            self._build_ui(); self._start_poll()
        else:
            messagebox.showerror("Erreur", "Connexion impossible (mauvais identifiants)")

    def _build_ui(self):
        for w in self.root.winfo_children(): w.destroy()
        self.root.configure(bg=BG)

        panes = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, sashwidth=2, bg="#ccc")
        panes.pack(fill="both", expand=True)
        left = tk.Frame(panes, bg=DARK2); right = tk.Frame(panes, bg=BG)
        panes.add(left, width=200, minsize=130); panes.add(right, width=650, minsize=280)

        tk.Label(left, text="Salons", bg=DARK3, fg=ACCENT, font=("Segoe UI", 10, "bold")).pack(fill="x", padx=0, pady=0, ipady=4)

        self.tree = ttk.Treeview(left, show="tree", selectmode="browse")
        self.tree.pack(fill="both", expand=True)
        self.tree.insert("", "end", "general", text="  #general", open=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_channel_select)
        self.tree.selection_set("general")

        btn_f = tk.Frame(left, bg=DARK2)
        btn_f.pack(fill="x", pady=4, padx=4)
        if self.client.role == "admin":
            tk.Button(btn_f, text="+ Salon", command=self._join_dialog, bg=BTN, fg=BTN_FG, font=("Segoe UI", 9), bd=0, cursor="hand2").pack(side="left", fill="x", expand=True, padx=(0,2))
            tk.Button(btn_f, text="- Suppr", command=self._delete_dialog, bg="#c62828", fg="white", font=("Segoe UI", 9), bd=0, cursor="hand2").pack(side="right", fill="x", expand=True, padx=(2,0))
        else:
            tk.Label(btn_f, text=f"Connecte : {self.client.nick}", bg=DARK2, fg="#888", font=("Segoe UI", 9)).pack()

        hdr = tk.Frame(right, bg=DARK3)
        hdr.pack(fill="x")
        self.chan_label = tk.Label(hdr, text="Messages  #general", bg=DARK3, fg=ACCENT, font=("Segoe UI", 10, "bold"), anchor="w")
        self.chan_label.pack(fill="x", padx=10, pady=4)

        self.msg_text = tk.Text(right, bg="white", fg=FG, insertbackground=ACCENT, font=("Segoe UI", 10), relief="solid", bd=1, padx=10, pady=6, state="disabled", wrap="word")
        self.msg_scroll = tk.Scrollbar(right, orient="vertical", command=self.msg_text.yview, bg="#ddd", troughcolor="white")
        self.msg_text.configure(yscrollcommand=self.msg_scroll.set)
        self.msg_text.pack(side="left", fill="both", expand=True, padx=(6,0), pady=4)
        self.msg_scroll.pack(side="right", fill="y", pady=4)

        bottom = tk.Frame(right, bg=BG)
        bottom.pack(fill="x", padx=6, pady=(0,6))
        self.entry = tk.Entry(bottom, font=("Segoe UI", 11), bd=2, relief="solid")
        self.entry.pack(side="left", fill="x", expand=True, ipady=4)
        self.entry.bind("<Return>", self._send_msg)
        tk.Button(bottom, text="Envoyer", command=self._send_msg, bg=BTN, fg=BTN_FG, font=("Segoe UI", 10, "bold"), bd=0, padx=15, cursor="hand2").pack(side="right", padx=(5,0))

        self.root.title(f"PeerSync - {self.client.nick}")
        self._refresh_msgs()

    def _join_dialog(self):
        ch = simpledialog.askstring("Creer un salon", "Nom du salon :", parent=self.root)
        if ch and ch.strip():
            ch = ch.strip().lower().replace(" ", "-")
            if self.client.create_channel(ch):
                if ch not in self.client.channels:
                    self.client.channels[ch] = []
                    self.tree.insert("", "end", ch, text=f"  #{ch}", open=True)
                self.tree.selection_set(ch)
            else:
                messagebox.showerror("Erreur", "Impossible de creer le salon")

    def _delete_dialog(self):
        ch = self._current_channel()
        if ch == "general": messagebox.showerror("Erreur", "Impossible de supprimer #general"); return
        if messagebox.askyesno("Supprimer", f"Supprimer #{ch} ?"):
            if self.client.delete_channel(ch):
                self.tree.delete(ch)
                if ch in self.client.channels: del self.client.channels[ch]
                self.tree.selection_set("general")
                self._refresh_msgs()
            else:
                messagebox.showerror("Erreur", "Impossible de supprimer")

    def _on_channel_select(self, e):
        sel = self.tree.selection()
        if sel:
            self.chan_label.configure(text=f"Messages  #{sel[0]}")
            self._refresh_msgs()

    def _current_channel(self):
        sel = self.tree.selection(); return sel[0] if sel else "general"

    def _send_msg(self, event=None):
        text = self.entry.get().strip()
        if not text: return
        ch = self._current_channel()
        self.client.send_msg(ch, text)
        self.entry.delete(0, "end")
        self._refresh_msgs()

    def _refresh_msgs(self):
        self.msg_text.configure(state="normal")
        self.msg_text.delete("1.0", "end")
        ch = self._current_channel()
        msgs = [m for m in self.client.all_msgs if m["chan"] == ch]
        for m in msgs[-200:]:
            nick = m["user"]
            text = m["text"]
            tag = "me" if nick == self.client.nick else "them"
            t = time.strftime("%H:%M", time.localtime(m["id"]/1000))
            self.msg_text.insert("end", f"{t} ", ("time",))
            self.msg_text.insert("end", f"<{nick}>", (tag,))
            self.msg_text.insert("end", f" {text}\n", ("msg",))
        self.msg_text.tag_config("time", foreground="#999", font=("Segoe UI", 9))
        self.msg_text.tag_config("me", foreground=ACCENT, font=("Segoe UI", 10, "bold"))
        self.msg_text.tag_config("them", foreground="#e65100", font=("Segoe UI", 10, "bold"))
        self.msg_text.tag_config("msg", foreground=FG, font=("Segoe UI", 10))
        self.msg_text.configure(state="disabled")
        self.msg_text.see("end")

    def _start_poll(self):
        def poll():
            known = set(self.client.channels.keys())
            while self.client.running:
                new = self.client.poll()
                if new: self.root.after(0, self._refresh_msgs)
                for c in self.client.channels:
                    if c not in known:
                        known.add(c)
                        self.root.after(0, lambda ch=c: self.tree.insert("", "end", ch, text=f"  #{ch}", open=True) if ch not in self.tree.get_children() else None)
                time.sleep(2)
        threading.Thread(target=poll, daemon=True).start()

    def _quit(self):
        self.client.running = False; self.root.destroy()

def main():
    app = ChatGUI(); app.root.mainloop()

if __name__ == "__main__":
    main()

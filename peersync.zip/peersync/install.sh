#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=== PeerSync Chat Install (Linux) ==="
read -rp "Serveur (host:port) [serverirc2-production.up.railway.app:443]: " SERVER
SERVER=${SERVER:-serverirc2-production.up.railway.app:443}
read -rsp "Mot de passe (laisse vide si node): " PASSWORD
echo ""

if [ -n "$PASSWORD" ]; then
  echo "{\"hub\": \"$SERVER\", \"pass\": \"$PASSWORD\"}" > "$DIR/config.json"
else
  echo "{\"hub\": \"$SERVER\"}" > "$DIR/config.json"
fi

# Install tkinter if missing
if ! python3 -c "import tkinter" 2>/dev/null; then
    echo "Installation de tkinter..."
    if command -v apt &>/dev/null; then
        sudo apt install -y python3-tk 2>/dev/null || echo "sudo nécessaire pour tkinter"
    elif command -v pacman &>/dev/null; then
        sudo pacman -S --noconfirm tk 2>/dev/null || echo "sudo nécessaire pour tk"
    fi
fi

mkdir -p ~/.local/share/applications
cat > ~/.local/share/applications/peersync.desktop << EOF
[Desktop Entry]
Type=Application
Name=PeerSync Chat
Exec=python3 "$DIR/client.py"
Icon=utilities-terminal
Terminal=false
Categories=Network;Chat;
EOF

mkdir -p ~/.config/autostart
cp ~/.local/share/applications/peersync.desktop ~/.config/autostart/

echo "Installation terminee ! Lancement..."
python3 "$DIR/client.py" &
echo "PeerSync Chat est lance."

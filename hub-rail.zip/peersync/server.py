import json, os, socket, sys, threading, time, hashlib

DATA = "data/chat.json"
USERS_FILE = "data/users.json"
os.makedirs("data", exist_ok=True)

def load_users():
    try:
        if os.path.exists(USERS_FILE): return json.loads(open(USERS_FILE).read())
    except: pass
    return {}

def save_users(u): open(USERS_FILE, "w").write(json.dumps(u))

users = load_users()
if not users:
    users["laiton"] = {"pass": hashlib.sha256(b"1103").hexdigest(), "role": "admin"}
    users["nicolas"] = {"pass": hashlib.sha256(b"nic0las#77").hexdigest(), "role": "normal"}
    users["antoine"] = {"pass": hashlib.sha256(b"ant01ne*42").hexdigest(), "role": "normal"}
    users["theodort"] = {"pass": hashlib.sha256(b"th30d0rt!9").hexdigest(), "role": "normal"}
    users["thibault"] = {"pass": hashlib.sha256(b"th1b@ult55").hexdigest(), "role": "normal"}
    users["marlone"] = {"pass": hashlib.sha256(b"m@rl0ne88").hexdigest(), "role": "normal"}
    users["tiago"] = {"pass": hashlib.sha256(b"t14g0#31").hexdigest(), "role": "normal"}
    users["sacha"] = {"pass": hashlib.sha256(b"s@ch@64!").hexdigest(), "role": "normal"}
    users["marius"] = {"pass": hashlib.sha256(b"m@r1us29").hexdigest(), "role": "normal"}
    users["mathys"] = {"pass": hashlib.sha256(b"m@thys91").hexdigest(), "role": "normal"}
    save_users(users)

def auth_user(nick, password):
    h = hashlib.sha256(password.encode()).hexdigest()
    u = users.get(nick)
    if u and u["pass"] == h: return u["role"]
    return None

def register_user(nick, password):
    return False

def load():
    try:
        if os.path.exists(DATA): return json.loads(open(DATA).read())
    except: pass
    return {"channels": ["general"], "messages": []}

def save(d): open(DATA, "w").write(json.dumps(d))

db = load()
lock = threading.Lock()

def add_msg(user, text, chan):
    with lock:
        m = {"id": int(time.time()*1000), "user": user, "text": text, "chan": chan}
        db["messages"].append(m)
        if chan not in db["channels"]: db["channels"].append(chan)
        save(db)
    return m

def msgs_since(after=0):
    return [m for m in db["messages"] if m["id"] > after]

def json_resp(conn, data, status=200):
    r = json.dumps(data).encode()
    conn.sendall(f"HTTP/1.1 {status} OK\r\nContent-Type: application/json\r\nContent-Length: {len(r)}\r\nAccess-Control-Allow-Origin: *\r\n\r\n".encode() + r)

def text_resp(conn, text, status=200):
    conn.sendall(f"HTTP/1.1 {status} OK\r\nContent-Length: {len(text)}\r\n\r\n{text}".encode())

def err_resp(conn, code=400):
    conn.sendall(f"HTTP/1.1 {code} Bad Request\r\nContent-Length: 0\r\n\r\n".encode())

def handle_http(conn, data):
    try:
        line, rest = data.split(b"\r\n", 1)
        method, path, _ = line.decode(errors="replace").split(" ", 2)
        body = b""
        if method in ("POST", "PUT"):
            for part in rest.split(b"\r\n\r\n"):
                if b"{" in part or b"Content-Length" in rest:
                    hdrs, body = rest.split(b"\r\n\r\n", 1)
                    break
        qs = ""
        if "?" in line.decode(errors="replace"):
            qs = line.decode(errors="replace").split(" ")[1].split("?", 1)[1] if "?" in line.decode(errors="replace").split(" ")[1] else ""
        path = path.split("?")[0]

        if path == "/api/login" and method == "POST":
            j = json.loads(body.decode())
            role = auth_user(j.get("user",""), j.get("pass",""))
            if role: json_resp(conn, {"ok": True, "role": role})
            else: json_resp(conn, {"ok": False, "error": "Mauvais identifiants"}, 401)

        elif path == "/api/register" and method == "POST":
            j = json.loads(body.decode())
            if register_user(j.get("user",""), j.get("pass","")):
                json_resp(conn, {"ok": True, "role": "normal"})
            else:
                json_resp(conn, {"ok": False, "error": "Pseudo deja pris"}, 409)

        elif path == "/api/msgs" and method == "GET":
            after = 0
            if qs:
                for p in qs.split("&"):
                    if "=" in p and p.split("=")[0] == "after":
                        after = int(p.split("=")[1])
            msgs = msgs_since(after)
            json_resp(conn, msgs)

        elif path == "/api/send" and method == "POST":
            j = json.loads(body.decode())
            user, passwd, text, chan = j.get("user",""), j.get("pass",""), j.get("text",""), j.get("chan","general")
            if not auth_user(user, passwd):
                json_resp(conn, {"ok": False, "error": "Non authentifie"}, 401)
            else:
                m = add_msg(user, text, chan)
                json_resp(conn, m)

        elif path == "/api/channels" and method == "GET":
            json_resp(conn, db["channels"])

        elif path == "/api/channels/create" and method == "POST":
            j = json.loads(body.decode())
            user, passwd, chan = j.get("user",""), j.get("pass",""), j.get("chan","")
            role = auth_user(user, passwd)
            if not role: json_resp(conn, {"ok": False, "error": "Non authentifie"}, 401)
            elif role != "admin": json_resp(conn, {"ok": False, "error": "Admin requis"}, 403)
            elif not chan: json_resp(conn, {"ok": False, "error": "Nom invalide"}, 400)
            else:
                with lock:
                    if chan not in db["channels"]:
                        db["channels"].append(chan)
                        save(db)
                json_resp(conn, {"ok": True, "chan": chan})

        elif path == "/api/channels/delete" and method == "POST":
            j = json.loads(body.decode())
            user, passwd, chan = j.get("user",""), j.get("pass",""), j.get("chan","")
            role = auth_user(user, passwd)
            if not role: json_resp(conn, {"ok": False, "error": "Non authentifie"}, 401)
            elif role != "admin": json_resp(conn, {"ok": False, "error": "Admin requis"}, 403)
            elif chan == "general": json_resp(conn, {"ok": False, "error": "Impossible de supprimer general"}, 400)
            else:
                with lock:
                    if chan in db["channels"]: db["channels"].remove(chan)
                    db["messages"] = [m for m in db["messages"] if m["chan"] != chan]
                    save(db)
                json_resp(conn, {"ok": True})

        elif path == "/api/role" and method == "POST":
            j = json.loads(body.decode())
            role = auth_user(j.get("user",""), j.get("pass",""))
            if role: json_resp(conn, {"ok": True, "role": role, "user": j.get("user","")})
            else: json_resp(conn, {"ok": False}, 401)

        elif path == "/health" or path == "/":
            text_resp(conn, "ok\n")

        else:
            err_resp(conn, 404)
    except:
        try: err_resp(conn, 400)
        except: pass
    finally:
        try: conn.close()
        except: pass

def irc_handler(conn):
    nick, buf = "user", b""
    try:
        conn.settimeout(300)
        conn.sendall(b":chat 001 * :Welcome to Chat\r\n")
        while True:
            d = conn.recv(4096)
            if not d: break
            buf += d
            while b"\r\n" in buf:
                line, buf = buf.split(b"\r\n", 1)
                raw = line.decode(errors="replace").strip()
                if not raw: continue
                p = raw.split()
                c = p[0].upper()
                if c == "NICK" and len(p) > 1:
                    nick = p[1]
                    conn.sendall(f":{nick} NICK {nick}\r\n".encode())
                elif c == "USER":
                    conn.sendall(f":chat 001 {nick} :Welcome\r\n:chat 376 {nick} :End MOTD\r\n".encode())
                elif c == "PING":
                    conn.sendall(b"PONG :chat\r\n")
                elif c == "JOIN" and len(p) > 1:
                    ch = p[1].lstrip("#")
                    conn.sendall(f":{nick} JOIN #{ch}\r\n:chat 353 {nick} = #{ch} :@{nick}\r\n:chat 366 {nick} #{ch} :End\r\n".encode())
                elif c == "PRIVMSG" and len(p) > 2:
                    t = p[1].lstrip("#")
                    txt = " ".join(p[2:]).lstrip(":")
                    add_msg(nick, txt, t)
                    conn.sendall(f":{nick} PRIVMSG #{t} :{txt}\r\n".encode())
                elif c == "LIST":
                    r = ":chat 321 * Channels\r\n"
                    for ch in db["channels"]: r += f":chat 322 * #{ch} 1\r\n"
                    r += ":chat 323 * :End\r\n"
                    conn.sendall(r.encode())
                elif c == "HIST":
                    t = p[1].lstrip("#") if len(p) > 1 else "general"
                    for m in msgs_since(0):
                        if m["chan"] == t:
                            conn.sendall(f":{m['user']} PRIVMSG #{m['chan']} :{m['text']}\r\n".encode())
                elif c == "POLL":
                    after = int(p[1]) if len(p) > 1 else 0
                    for m in msgs_since(after):
                        conn.sendall(f":{m['user']} PRIVMSG #{m['chan']} :{m['text']}\r\n".encode())
                elif c in ("QUIT", "ERROR"):
                    conn.sendall(b"ERROR :bye\r\n")
                    break
    except:
        pass
    finally:
        try: conn.close()
        except: pass

HTTP_METHODS = {b"GET", b"POST", b"PUT", b"DELETE", b"PATCH", b"HEAD", b"OPTIONS"}

PORT = int(os.environ.get("PORT", 8000))
srv = socket.socket()
srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(("0.0.0.0", PORT))
srv.listen(64)
print(f"Chat ready on :{PORT}", flush=True)
sys.stdout.flush()

while True:
    try:
        c, a = srv.accept()
        peek = c.recv(4, socket.MSG_PEEK)
        if peek[:3] in HTTP_METHODS or peek[:4] in HTTP_METHODS:
            data = c.recv(8192)
            threading.Thread(target=handle_http, args=(c, data), daemon=True).start()
        else:
            threading.Thread(target=irc_handler, args=(c,), daemon=True).start()
    except KeyboardInterrupt:
        break
    except:
        pass
